package com.example.notification;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.ResourcesCompat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
private static final String CHANNEL_ID="My channel";
//    private static final int REQ_CODE= 100;
    Button bt;
    private static final int NOTIFICATION_ID= 100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bt=findViewById(R.id.bt1);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                not();
            }
        });
    }
 public void  not()
    {
        Drawable drawable = ResourcesCompat.getDrawable(getResources(), R.drawable.new_icon, null);

        BitmapDrawable bitmapDrawable = (BitmapDrawable) drawable;

        Bitmap largeIcon = bitmapDrawable.getBitmap();

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification notification;

//
//        Notification.BigPictureStyle bigPictureStyle=new Notification.BigPictureStyle()
//                .bigPicture(((BitmapDrawable) ResourcesCompat.getDrawable(getResources(), R.drawable.new_icon, null)).getBitmap())
//                .bigLargeIcon(largeIcon)
//                .setBigContentTitle("Code soft intenship")
//                .setSummaryText("COde soft message");

//        Notification.InboxStyle inboxStyle=new Notification.InboxStyle()
//                .addLine("H")
//                .addLine("E")
//                .addLine("E")
//                .addLine("L")
//                .addLine("O")
//                .setBigContentTitle("Full Message")
//                .setSummaryText("Message Message");

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            notification = new Notification.Builder(this)
                    .setLargeIcon(largeIcon)
                    .setSmallIcon(R.drawable.new_icon)
                    .setSubText("new Message")
                    .setContentText("New Message from codesoft")
                    .setChannelId(CHANNEL_ID)
                    .build();
            nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID, "New Channel", NotificationManager.IMPORTANCE_HIGH));
        } else {
            notification = new Notification.Builder(this)
                    .setLargeIcon(largeIcon)
                    .setSmallIcon(R.drawable.new_icon)
                    .setContentText("new Message")
                    .setSubText("New Message from codesoft")
                    .build();
        }
        nm.notify(NOTIFICATION_ID, notification);
    }
}